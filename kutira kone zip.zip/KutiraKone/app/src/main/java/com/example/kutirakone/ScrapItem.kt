package com.example.kutirakone

data class ScrapItem(
    val title: String,
    val material: String,
    val size: String,
    val location: String,
    val distanceKm: Int,
    val photoUri: String,
    val color: Int
)
