# Kutira-Kone Android App

Kutira-Kone is a zero-waste fabric exchange app for home-based tailors and local artisans.

## Main File Name

Open this folder in Android Studio:

`KutiraKone`

Main activity file:

`app/src/main/java/com/example/kutirakone/MainActivity.kt`

## Features

- Login as Sender / Tailor or Receiver / Artisan.
- Sender users can upload fabric scraps.
- Receiver users can browse scraps and request trades.
- Colorful fabric scrap catalog in a 2-column grid.
- Upload form that requires one clear fabric photo.
- Search by material type: Cotton, Silk, Wool, Denim.
- Radius filter such as within 5 km.
- Direct swap / trade request button.
- Simulated GenAI design ideas for leftover scraps.

## How To Run

1. Open Android Studio.
2. Choose **Open**.
3. Select the `KutiraKone` folder.
4. Let Gradle sync.
5. Run the app on an emulator or Android phone.

## Firebase Firestore Note

This student-ready version runs locally with sample data so it works immediately.
For a real Firebase version, add Firebase to the Android project from Android Studio:

1. Tools > Firebase > Firestore.
2. Connect to Firebase.
3. Add the Firestore SDK.
4. Replace the local `allScraps` list in `MainActivity.java` with Firestore reads and writes.
