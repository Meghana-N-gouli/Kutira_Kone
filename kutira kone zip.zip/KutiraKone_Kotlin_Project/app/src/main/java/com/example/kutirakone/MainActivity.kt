package com.example.kutirakone

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val allScraps = mutableListOf<ScrapItem>()
    private var catalogGrid: GridLayout? = null
    private var materialFilter: Spinner? = null
    private var radiusLabel: TextView? = null
    private var selectedRadiusKm = 5
    private var selectedUploadPhoto: Uri? = null
    private var uploadPreview: ImageView? = null
    private var currentUserName = ""
    private var currentUserRole = ROLE_RECEIVER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        seedScraps()
        setContentView(buildLoginScreen())
    }

    private fun buildLoginScreen(): View {
        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFFFFF7EC.toInt())
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        scrollView.addView(root)

        root.addView(text("Kutira-Kone Login", 30, 0xFF263238.toInt(), true))
        root.addView(text("Choose your role to enter the fabric exchange", 15, 0xFF546E7A.toInt()).apply {
            setPadding(0, dp(6), 0, dp(18))
        })

        val loginCard = cardContainer()
        val nameInput = input("Full name")
        val phoneInput = input("Phone number")
        val roleSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf(ROLE_SENDER, ROLE_RECEIVER)
            )
        }

        loginCard.addView(label("User Name"))
        loginCard.addView(nameInput)
        loginCard.addView(label("Phone Number"))
        loginCard.addView(phoneInput)
        loginCard.addView(label("Login As"))
        loginCard.addView(roleSpinner)
        loginCard.addView(button("Login", 0xFF2A9D8F.toInt()).apply {
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                val phone = phoneInput.text.toString().trim()
                if (name.isEmpty() || phone.length < 10) {
                    toast("Enter name and valid 10 digit phone number.")
                    return@setOnClickListener
                }

                currentUserName = name
                currentUserRole = roleSpinner.selectedItem.toString()
                setContentView(buildScreen())
                renderCatalog()
            }
        })

        root.addView(loginCard)
        return scrollView
    }

    private fun openMarketplace() {
        setContentView(buildScreen())
        renderCatalog()
    }

    @Deprecated("Used for a simple student-friendly image picker.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FABRIC_PHOTO && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedUploadPhoto = uri
                uploadPreview?.apply {
                    setImageURI(uri)
                    setBackgroundColor(0x00000000)
                }
            }
        }
    }

    private fun buildScreen(): View {
        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFFFFF7EC.toInt())
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(22))
        }
        scrollView.addView(root)

        root.addView(text("Kutira-Kone", 30, 0xFF263238.toInt(), true))
        root.addView(text("Zero-waste fabric exchange for local tailors and artisans", 15, 0xFF546E7A.toInt()).apply {
            setPadding(0, dp(4), 0, dp(14))
        })

        root.addView(text("Logged in: $currentUserName - $currentUserRole", 14, 0xFF37474F.toInt(), true).apply {
            setPadding(0, 0, 0, dp(10))
        })

        root.addView(button("Logout", 0xFF607D8B.toInt()).apply {
            setOnClickListener {
                currentUserName = ""
                currentUserRole = ROLE_RECEIVER
                setContentView(buildLoginScreen())
            }
        })

        if (currentUserRole == ROLE_SENDER) {
            root.addView(button("+ Upload Fabric Scrap", 0xFFE85D75.toInt()).apply {
                setOnClickListener { showUploadDialog() }
            })
        } else {
            root.addView(text("Receiver mode: browse scraps and request trades from nearby senders.", 14, 0xFF546E7A.toInt()).apply {
                setPadding(0, dp(10), 0, 0)
            })
        }

        root.addView(sectionTitle("Browse Nearby Scraps"))
        root.addView(buildFilters())

        catalogGrid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = true
        }
        root.addView(catalogGrid)

        root.addView(sectionTitle("Design Ideas"))
        root.addView(buildDesignIdeas())

        return scrollView
    }

    private fun buildFilters(): View {
        val box = cardContainer()

        materialFilter = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("All Materials", "Cotton", "Silk", "Wool", "Denim")
            )
        }

        box.addView(label("Material Type"))
        box.addView(materialFilter)

        radiusLabel = label("Radius: within 5 km").apply {
            setPadding(0, dp(12), 0, 0)
        }
        box.addView(radiusLabel)

        box.addView(SeekBar(this).apply {
            max = 20
            progress = 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    selectedRadiusKm = progress.coerceAtLeast(1)
                    radiusLabel?.text = String.format(Locale.getDefault(), "Radius: within %d km", selectedRadiusKm)
                    renderCatalog()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        })

        box.addView(button("Search", 0xFF2A9D8F.toInt()).apply {
            setOnClickListener { renderCatalog() }
        })

        return box
    }

    private fun buildDesignIdeas(): View {
        val box = cardContainer()
        val ideas = listOf(
            "Cotton bits -> reusable masks and hair bands",
            "Silk scraps -> festive patchwork pouches",
            "Denim pieces -> sturdy coin purses",
            "Mixed leftovers -> doll dresses and quilt blocks"
        )

        ideas.forEach { idea ->
            box.addView(text(idea, 15, 0xFF37474F.toInt()).apply {
                setPadding(0, dp(7), 0, dp(7))
            })
        }
        return box
    }

    private fun showUploadDialog() {
        selectedUploadPhoto = null

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(2))
        }

        uploadPreview = ImageView(this).apply {
            minimumHeight = dp(150)
            setBackgroundColor(0xFFE0E0E0.toInt())
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        form.addView(uploadPreview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)))

        form.addView(button("Choose Clear Photo", 0xFF457B9D.toInt()).apply {
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                }
                startActivityForResult(Intent.createChooser(intent, "Choose fabric photo"), PICK_FABRIC_PHOTO)
            }
        })

        val title = input("Fabric title, e.g., Blue cotton floral")
        val size = input("Approx size, e.g., 0.5 meters")
        val location = input("Village/local area")
        val distance = input("Distance from you in km, e.g., 3")
        val material = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Cotton", "Silk", "Wool", "Denim")
            )
        }

        form.addView(title)
        form.addView(material)
        form.addView(size)
        form.addView(location)
        form.addView(distance)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Upload Fabric Scrap")
            .setView(form)
            .setPositiveButton("List Scrap", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                when {
                    selectedUploadPhoto == null -> {
                        toast("Upload needs at least one clear photo.")
                    }
                    title.text.toString().trim().isEmpty() || size.text.toString().trim().isEmpty() -> {
                        toast("Please enter title and approximate size.")
                    }
                    else -> {
                        allScraps.add(
                            0,
                            ScrapItem(
                                title = title.text.toString().trim(),
                                material = material.selectedItem.toString(),
                                size = size.text.toString().trim(),
                                location = location.text.toString().trim().ifEmpty { "Nearby artisan" },
                                distanceKm = parseDistance(distance.text.toString()),
                                photoUri = selectedUploadPhoto.toString(),
                                color = 0xFF2A9D8F.toInt()
                            )
                        )
                        renderCatalog()
                        toast("Scrap listed for local exchange.")
                        dialog.dismiss()
                    }
                }
            }
        }

        dialog.show()
    }

    private fun renderCatalog() {
        val grid = catalogGrid ?: return
        grid.removeAllViews()

        val selectedMaterial = materialFilter?.selectedItem?.toString() ?: "All Materials"
        allScraps
            .filter { scrap ->
                (selectedMaterial == "All Materials" || scrap.material == selectedMaterial) &&
                    scrap.distanceKm <= selectedRadiusKm
            }
            .forEach { scrap -> grid.addView(scrapCard(scrap)) }

        if (grid.childCount == 0) {
            grid.addView(text("No scraps found. Try increasing radius or changing material.", 15, 0xFF607D8B.toInt()).apply {
                setPadding(dp(4), dp(14), dp(4), dp(14))
            })
        }
    }

    private fun scrapCard(scrap: ScrapItem): View {
        val card = cardContainer().apply {
            layoutParams = GridLayout.LayoutParams().apply {
                width = resources.displayMetrics.widthPixels / 2 - dp(28)
                setMargins(0, 0, dp(6), dp(10))
            }
        }

        card.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(scrap.color)
            if (scrap.photoUri.isNotEmpty()) {
                setImageURI(Uri.parse(scrap.photoUri))
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(112)))

        card.addView(text(scrap.title, 16, 0xFF263238.toInt(), true))
        card.addView(text("${scrap.material} - ${scrap.size}", 13, 0xFF546E7A.toInt()))
        card.addView(text("${scrap.location} - ${scrap.distanceKm} km", 13, 0xFF546E7A.toInt()))
        if (currentUserRole == ROLE_RECEIVER) {
            card.addView(button("Request Trade", 0xFFF4A261.toInt()).apply {
                setOnClickListener { toast("Trade request sent to sender for ${scrap.title}") }
            })
        } else {
            card.addView(text("Sender view: receivers can request this scrap.", 12, 0xFF607D8B.toInt()).apply {
                setPadding(0, dp(6), 0, 0)
            })
        }

        return card
    }

    private fun seedScraps() {
        allScraps.add(ScrapItem("Pink floral bits", "Cotton", "0.5 meters", "Hanuman Nagar", 2, "", 0xFFE85D75.toInt()))
        allScraps.add(ScrapItem("Gold blouse silk", "Silk", "0.3 meters", "Market Road", 4, "", 0xFFE9C46A.toInt()))
        allScraps.add(ScrapItem("Blue denim strips", "Denim", "0.8 meters", "Bus Stand Area", 6, "", 0xFF457B9D.toInt()))
        allScraps.add(ScrapItem("Warm wool patches", "Wool", "0.4 meters", "Temple Street", 3, "", 0xFF8D6E63.toInt()))
        allScraps.add(ScrapItem("White cotton lining", "Cotton", "1 meter", "School Road", 8, "", 0xFF90BE6D.toInt()))
        allScraps.add(ScrapItem("Green silk border", "Silk", "0.2 meters", "Lake Colony", 5, "", 0xFF2A9D8F.toInt()))
    }

    private fun cardContainer() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setBackgroundResource(R.drawable.card_background)
    }

    private fun sectionTitle(value: String) = text(value, 21, 0xFF263238.toInt(), true).apply {
        setPadding(0, dp(18), 0, dp(8))
    }

    private fun label(value: String) = text(value, 14, 0xFF37474F.toInt(), true).apply {
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText
        setSingleLine(true)
        setPadding(0, dp(10), 0, dp(6))
    }

    private fun button(value: String, color: Int) = Button(this).apply {
        text = value
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(color)
    }

    private fun text(value: String, sp: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = sp.toFloat()
        setTextColor(color)
        gravity = Gravity.START
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun parseDistance(raw: String): Int = raw.trim().toIntOrNull()?.coerceAtLeast(1) ?: 1

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val PICK_FABRIC_PHOTO = 101
        private const val ROLE_SENDER = "Sender / Tailor"
        private const val ROLE_RECEIVER = "Receiver / Artisan"
    }
}
